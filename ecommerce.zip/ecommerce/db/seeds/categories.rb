Category.create(name: "Smartphones")
Category.create(name: "Zapatos")
Category.create(name: "Accesorios")